import React from 'react';
import ReactDOM from 'react-dom';
import { Sparklines, SparklinesBars,SparklinesLine, SparklinesSpots } from 'react-sparklines';
import TestData from './mock-data.json';

export default class App extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = {
            data:TestData
        }
    }

    render() {
        return(
           <Sparklines  width="240" height="60" data={this.state.data} limit={20}>
    <SparklinesLine  color="#1c8cdc" />
    <SparklinesSpots/>
</Sparklines> 
        );
    }
}
