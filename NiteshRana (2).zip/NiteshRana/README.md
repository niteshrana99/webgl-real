## Steps to run this project.

- Go to root folder of this project.

- Open 'Command propmt' and type `npm start`.